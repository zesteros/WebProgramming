
Hola <?php echo htmlspecialchars($_GET['user']); ?>.
Usted tiene este password<?php echo $_GET['password']; ?>.
