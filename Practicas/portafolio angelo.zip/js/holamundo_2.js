var hello = "Hola mundo!\nQue fácil es incluir  \'Comillas simples\' y \"Comillas dobles\"";
alert(hello);